# -*- coding: utf-8 -*-
"""
tools/generate_docs.py -- GUI генератор проектной документации
Создаёт TXT и PDF (через reportlab или matplotlib).

Запуск: python tools/generate_docs.py
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import datetime
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import customtkinter as ctk
from config import (APP_TITLE, COMPANY_NAME, DB_FILE, DOC_META,
                    MAX_LOGIN_ATTEMPTS, TYPEFACE)
from ui_theme import P, F, init_theme, btn, lbl, entry, header_bar

# ──────────────────────────────────────────────
#  Шаблон документации
# ──────────────────────────────────────────────

DOC_TEMPLATE = """\
================================================================================
  ПРОЕКТНАЯ ДОКУМЕНТАЦИЯ
  {title}
  {company}
  Дата: {date}    Версия: {version}    Автор: {author}
================================================================================

1. ФУНКЦИОНАЛЬНОЕ НАЗНАЧЕНИЕ
--------------------------------------------------------------------------------
{purpose}

2. АРХИТЕКТУРА ПРИЛОЖЕНИЯ
--------------------------------------------------------------------------------
Приложение реализовано на языке Python. Структура проекта:

  fonts/             -- Montserrat-Regular/Medium/SemiBold/Bold.ttf
  fonts.py           -- загрузка шрифтов в процесс Python
  ui_theme.py        -- единая тёмная тема интерфейса
  config.py          -- настройка: цвета, шрифты, название, SQL запрос
  storage.py         -- работа с SQLite (CRUD, авторизация)
  app.py             -- главный GUI (авторизация, просмотр данных)
  tools/
    db_builder.py    -- визуальный конструктор структуры БД
    er_diagram.py    -- генератор ER-диаграммы (matplotlib, без EXE)
    generate_docs.py -- этот скрипт (TXT + PDF)

3. БАЗА ДАННЫХ
--------------------------------------------------------------------------------
Тип СУБД: SQLite 3
Файл:     database.db

{db_section}

4. ОПИСАНИЕ КЛЮЧЕВЫХ КОМПОНЕНТОВ
--------------------------------------------------------------------------------

4.1. storage.py

  bootstrap()
    Создаёт системные таблицы (Пользователи, UserRoles) при первом запуске.
    Инициализирует роли «Администратор» и «Пользователь», логин admin/admin.

  verify_credentials(login, password)
    Проверяет логин/пароль. Блокирует аккаунт после {max_attempts} неудач.
    Возвращает профиль пользователя или код ошибки.

  fetch_table(table, limit)
    Универсальное чтение любой таблицы. Используется в DataView.

  run_sql(query)
    Выполнение произвольного SQL-запроса.

4.2. app.py

  AppRunner        -- точка входа, управление навигацией
  AuthScreen       -- форма авторизации (CustomTkinter)
  MainShell        -- главное окно с вкладками
  DataView         -- просмотр и CRUD таблиц БД
  SqlQueryView     -- выполнение аналитического SQL (MODULE3_SQL из config)
  UsersPanel       -- управление пользователями и ролями
  RecordForm       -- диалог добавления/редактирования записи

5. СТЕК ТЕХНОЛОГИЙ
--------------------------------------------------------------------------------
  Python 3.x              -- язык разработки
  sqlite3 (встроен)       -- база данных
  tkinter / ttk (встроен) -- базовый GUI
  customtkinter           -- современный GUI (скругления, тёмная тема)
  matplotlib              -- ER-диаграммы и PDF документация
  reportlab               -- PDF документация (приоритетно)
  graphviz (python)       -- не используется (ER через matplotlib)

6. ТРЕБОВАНИЯ
--------------------------------------------------------------------------------
  ОС: Windows 10/11
  Python: 3.8+
  pip install -r requirements.txt

================================================================================
  Конец документации
================================================================================
"""


def collect_db(db_path):
    if not os.path.exists(db_path):
        return "  (база данных не найдена)"
    try:
        conn = sqlite3.connect(db_path)
        cur  = conn.cursor()
        cur.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
        tables = [r[0] for r in cur.fetchall()]
        lines = []
        for t in tables:
            cur.execute(f"PRAGMA table_info([{t}])")
            cols = cur.fetchall()
            cur.execute(f"SELECT COUNT(*) FROM [{t}]")
            cnt = cur.fetchone()[0]
            lines.append(f"  Таблица: {t}  (записей: {cnt})")
            for c in cols:
                pk = " [PK]" if c[5] else ""
                nn = " NOT NULL" if c[3] else ""
                lines.append(f"    * {c[1]}  {c[2]}{pk}{nn}")
            lines.append("")
        conn.close()
        return "\n".join(lines) or "  (таблиц нет)"
    except Exception as e:
        return f"  Ошибка чтения БД: {e}"


def render_doc(db_path=DB_FILE):
    return DOC_TEMPLATE.format(
        title        = APP_TITLE,
        company      = COMPANY_NAME,
        date         = datetime.date.today().strftime("%d.%m.%Y"),
        version      = DOC_META.get("version", "1.0"),
        author       = DOC_META.get("author",  "Студент"),
        purpose      = DOC_META.get("purpose", ""),
        db_section   = collect_db(db_path),
        max_attempts = MAX_LOGIN_ATTEMPTS,
    )


# ──────────────────────────────────────────────
#  GUI
# ──────────────────────────────────────────────

class DocsGenerator:
    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("Генератор проектной документации")
        self.root.geometry("960x720")
        init_theme(self.root)
        self._build()
        self._preview()

    def _build(self):
        # Шапка
        hdr = ctk.CTkFrame(self.root, fg_color=P["primary"],
                           corner_radius=0, height=48)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="Генератор проектной документации",
                     font=ctk.CTkFont(family="Montserrat", size=14, weight="bold"),
                     text_color="white").pack(side="left", padx=14, pady=12)

        top = ctk.CTkFrame(self.root, fg_color=P["bg"],
                           corner_radius=0, height=50)
        top.pack(fill="x", padx=14, pady=(8, 0)); top.pack_propagate(False)

        ctk.CTkLabel(top, text="БД:",
                     font=ctk.CTkFont(family="Montserrat", size=11)).pack(
            side="left")
        self._db_var = tk.StringVar(value=DB_FILE)
        ctk.CTkEntry(top, textvariable=self._db_var, width=380,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     border_color=P["border"],
                     fg_color=P["surface"]).pack(side="left", padx=6)
        ctk.CTkButton(top, text="...", width=40,
                      command=self._pick_db,
                      fg_color=P["border"], hover_color=P["row_b"],
                      corner_radius=6,
                      font=ctk.CTkFont(family="Montserrat", size=11)
                      ).pack(side="left", padx=2)
        ctk.CTkButton(top, text="Обновить превью",
                      command=self._preview,
                      fg_color=P["primary"], hover_color=P["primary_hover"],
                      font=ctk.CTkFont(family="Montserrat", size=10, weight="bold"),
                      corner_radius=8, height=30, width=160
                      ).pack(side="left", padx=10)

        # Текстовый превью
        text_frame = tk.Frame(self.root, bg=P["bg"])
        text_frame.pack(fill="both", expand=True, padx=14, pady=6)
        self._text = scrolledtext.ScrolledText(
            text_frame,
            font=TYPEFACE["mono"],
            bg=P["surface"], fg=P["text"],
            insertbackground=P["text"],
            bd=0, padx=8, pady=8,
        )
        self._text.pack(fill="both", expand=True)

        # Кнопки
        bot = ctk.CTkFrame(self.root, fg_color=P["bg"],
                           corner_radius=0, height=50)
        bot.pack(fill="x", padx=14, pady=(0, 10)); bot.pack_propagate(False)

        ctk.CTkButton(bot, text="Сохранить TXT",
                      command=self._save_txt,
                      fg_color=P["primary"], hover_color=P["primary_hover"],
                      font=ctk.CTkFont(family="Montserrat", size=10, weight="bold"),
                      corner_radius=8, height=34, width=150
                      ).pack(side="left", padx=4)
        ctk.CTkButton(bot, text="Сохранить PDF",
                      command=self._save_pdf,
                      fg_color=P["accent"], hover_color=P["primary"],
                      font=ctk.CTkFont(family="Montserrat", size=10, weight="bold"),
                      corner_radius=8, height=34, width=150,
                      text_color="#1A1625"
                      ).pack(side="left", padx=4)
        self._status = ctk.CTkLabel(bot, text="",
                                    font=ctk.CTkFont(family="Montserrat", size=9),
                                    text_color=P["text_muted"])
        self._status.pack(side="left", padx=10)

    def _pick_db(self):
        p = filedialog.askopenfilename(
            filetypes=[("SQLite", "*.db *.sqlite"), ("Все", "*.*")])
        if p:
            self._db_var.set(p)
            self._preview()

    def _preview(self):
        doc = render_doc(self._db_var.get().strip())
        self._text.delete("1.0", "end")
        self._text.insert("1.0", doc)

    def _get_doc(self):
        return self._text.get("1.0", "end").strip()

    def _save_txt(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Текст", "*.txt")],
            initialfile="Проектная_документация.txt")
        if not path: return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._get_doc())
            self._status.configure(
                text=f"TXT сохранён: {os.path.basename(path)}",
                text_color=P["success"])
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _save_pdf(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile="Проектная_документация.pdf")
        if not path: return

        text = self._get_doc()

        # Приоритет: reportlab (корректная кириллица)
        try:
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import ParagraphStyle
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont

            font_name = "Helvetica"
            for candidate in [
                r"C:\Windows\Fonts\arial.ttf",
                r"C:\Windows\Fonts\calibri.ttf",
            ]:
                if os.path.exists(candidate):
                    try:
                        pdfmetrics.registerFont(TTFont("DocFont", candidate))
                        font_name = "DocFont"
                        break
                    except Exception:
                        pass

            doc = SimpleDocTemplate(
                path, pagesize=A4,
                leftMargin=20*mm, rightMargin=20*mm,
                topMargin=20*mm, bottomMargin=20*mm)
            style = ParagraphStyle(
                "mono", fontName=font_name, fontSize=8, leading=12)
            story = [
                Paragraph(
                    line.replace("&", "&amp;").replace("<", "&lt;")
                        .replace(">", "&gt;") or " ",
                    style)
                for line in text.splitlines()
            ]
            doc.build(story)
            self._status.configure(
                text=f"PDF сохранён: {os.path.basename(path)}",
                text_color=P["success"])
            return
        except ImportError:
            pass

        # Fallback: matplotlib
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            fig, ax = plt.subplots(figsize=(8.27, 11.69))
            fig.patch.set_facecolor("#FFFFFF")
            ax.axis("off")
            ax.text(0.02, 0.98, text[:4500],
                    transform=ax.transAxes,
                    fontsize=6.2, verticalalignment="top",
                    family="monospace", color="#111111")
            plt.tight_layout(pad=0.3)
            plt.savefig(path, dpi=150, bbox_inches="tight",
                        facecolor="#FFFFFF")
            plt.close()
            self._status.configure(
                text=f"PDF (matplotlib) сохранён: {os.path.basename(path)}",
                text_color=P["success"])
        except Exception as e:
            messagebox.showerror(
                "Ошибка PDF",
                f"Не удалось создать PDF.\n"
                f"Установи: pip install reportlab\n\n{e}")

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    DocsGenerator().run()
