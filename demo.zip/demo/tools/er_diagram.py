# -*- coding: utf-8 -*-
"""
tools/er_diagram.py -- GUI генератор ER-диаграмм из SQLite БД
Только Python-модули: matplotlib. Graphviz EXE не нужен.

Запуск: python tools/er_diagram.py
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import sqlite3
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import customtkinter as ctk
from config import DB_FILE, TYPEFACE
from ui_theme import P, F, init_theme, init_ttk, btn, lbl, entry, header_bar

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyBboxPatch
    from matplotlib.lines import Line2D
    HAS_MPL = True
except ImportError:
    HAS_MPL = False


# ──────────────────────────────────────────────
#  Чтение схемы БД
# ──────────────────────────────────────────────

def read_schema(db_path):
    conn = sqlite3.connect(db_path)
    cur  = conn.cursor()
    cur.execute(
        "SELECT name FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )
    tables = [r[0] for r in cur.fetchall()]
    schema = {}
    for t in tables:
        cur.execute(f"PRAGMA table_info([{t}])")
        columns = [
            {"name": r[1], "type": r[2],
             "notnull": bool(r[3]), "pk": bool(r[5])}
            for r in cur.fetchall()
        ]
        cur.execute(f"PRAGMA foreign_key_list([{t}])")
        fks = [{"from": r[3], "to_table": r[2], "to_col": r[4]}
               for r in cur.fetchall()]
        schema[t] = {"columns": columns, "fks": fks}
    conn.close()
    return schema


# ──────────────────────────────────────────────
#  Рисование ER через matplotlib
# ──────────────────────────────────────────────

# Константы макета (в "единицах данных" matplotlib)
COL_GAP   = 7.5   # горизонтальный зазор между таблицами
ROW_GAP   = 3.0   # вертикальный зазор между рядами
BOX_W     = 5.5   # ширина блока таблицы
ROW_H     = 0.6   # высота одной строки поля
HDR_H     = 0.75  # высота заголовка таблицы
FONT_HDR  = 12
FONT_BODY = 10


def _calc_layout(schema):
    """Вычисляет позиции (центр верхнего края) каждой таблицы."""
    tables = list(schema.keys())
    n      = len(tables)
    
    # Адаптивное количество колонок: небольшие БД = меньше колонок
    if n <= 3:
        n_cols = n
    elif n <= 6:
        n_cols = 2
    elif n <= 12:
        n_cols = 3
    else:
        n_cols = 4

    positions = {}
    # Сортируем таблицы по количеству полей для более равномерного layout
    tables_sorted = sorted(tables, key=lambda t: len(schema[t]["columns"]), reverse=True)
    
    col_items = [[] for _ in range(n_cols)]  # списки таблиц в каждой колонке
    col_heights = [0.0] * n_cols
    
    # Распределяем таблицы по колонкам (балансируем по высоте)
    for t in tables_sorted:
        h = HDR_H + ROW_H * len(schema[t]["columns"])
        # Выбираем колонку с минимальной высотой
        min_col = col_heights.index(min(col_heights))
        col_items[min_col].append(t)
        col_heights[min_col] += h + ROW_GAP

    # Теперь вычисляем координаты
    for col_idx in range(n_cols):
        y_offset = 0.0
        for t in col_items[col_idx]:
            h = HDR_H + ROW_H * len(schema[t]["columns"])
            x = col_idx * (BOX_W + COL_GAP) + BOX_W / 2
            y_top = -y_offset
            positions[t] = (x, y_top)
            y_offset += h + ROW_GAP

    return positions, n_cols


def draw_er(schema,
            primary_color="#9C27B0",
            bg_color="#1A1625",
            surface_color="#241D35",
            text_color="#EDE7F6"):
    """Рисует ER-диаграмму, возвращает fig."""
    if not HAS_MPL:
        raise ImportError("matplotlib не установлен: pip install matplotlib")

    if not schema:
        raise ValueError("Схема пустая — нет таблиц")

    positions, n_cols = _calc_layout(schema)

    # ── Вычисляем bbox всех таблиц для настройки осей
    all_x, all_y = [], []
    box_info = {}  # tname -> (x_left, y_top, w, h)
    for tname, info in schema.items():
        cx, y_top = positions[tname]
        h = HDR_H + ROW_H * len(info["columns"])
        x_left = cx - BOX_W / 2
        box_info[tname] = (x_left, y_top, BOX_W, h)
        all_x += [x_left, x_left + BOX_W]
        all_y += [y_top, y_top - h]

    x_min, x_max = min(all_x), max(all_x)
    y_min, y_max = min(all_y), max(all_y)
    pad_x = 1.0
    pad_y = 1.0

    # ── Размер фигуры пропорционален содержимому (увеличено для читабельности)
    w_data = x_max - x_min + 2 * pad_x
    h_data = y_max - y_min + 2 * pad_y
    scale  = 1.6   # пикселей на единицу данных (в дюймах)
    fig_w  = max(12, min(24, w_data * scale))  # макс 24 дюйма
    fig_h  = max(9,  min(18, h_data * scale))  # макс 18 дюймов

    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    fig.patch.set_facecolor("white")  # БЕЛЫЙ ФОН
    ax.set_facecolor("white")         # БЕЛЫЙ ФОН
    ax.axis("off")
    ax.set_xlim(x_min - pad_x, x_max + pad_x)
    ax.set_ylim(y_min - pad_y, y_max + pad_y)
    ax.set_aspect("equal")

    # ── Рисуем блоки таблиц (БЕЛЫЙ ФОН, контрастные цвета)
    for tname, info in schema.items():
        x_left, y_top, bw, bh = box_info[tname]
        cx = x_left + bw / 2

        # Общий фон таблицы - светло-серый
        ax.add_patch(FancyBboxPatch(
            (x_left, y_top - bh), bw, bh,
            boxstyle="round,pad=0.05",
            linewidth=1.8,
            edgecolor="#424242",      # тёмно-серая рамка
            facecolor="#F5F5F5",      # светло-серый фон
            zorder=2,
        ))

        # Заголовок - синий насыщенный
        ax.add_patch(FancyBboxPatch(
            (x_left, y_top - HDR_H), bw, HDR_H,
            boxstyle="round,pad=0.03",
            linewidth=0,
            facecolor="#1565C0",      # синий заголовок
            zorder=3,
        ))
        ax.text(cx, y_top - HDR_H / 2, tname,
                ha="center", va="center",
                fontsize=FONT_HDR, fontweight="bold",
                color="white", zorder=4)

        # Разделитель под заголовком
        ax.plot([x_left + 0.08, x_left + bw - 0.08],
                [y_top - HDR_H, y_top - HDR_H],
                color="#1565C0", lw=1.0, zorder=4)

        fk_set = {fk["from"] for fk in info["fks"]}
        pk_set = {c["name"] for c in info["columns"] if c["pk"]}

        # Строки полей
        for i, col in enumerate(info["columns"]):
            cy = y_top - HDR_H - (i + 0.5) * ROW_H
            cn = col["name"]
            ct = col["type"]

            # Чередование фона строк (светлее/темнее серый)
            if i % 2 == 1:
                ax.add_patch(plt.Rectangle(
                    (x_left + 0.05, cy - ROW_H / 2 + 0.02),
                    bw - 0.10, ROW_H - 0.04,
                    facecolor="#E0E0E0", alpha=0.6,
                    linewidth=0, zorder=2,
                ))

            if cn in pk_set:
                badge, badge_c, name_c = "PK", "#F57C00", "#212121"  # оранжевый + чёрный
            elif cn in fk_set:
                badge, badge_c, name_c = "FK", "#0277BD", "#212121"  # синий + чёрный
            else:
                badge, badge_c, name_c = "",   "#212121", "#212121"  # чёрный

            # Бейдж PK/FK
            if badge:
                ax.text(x_left + 0.14, cy,
                        badge,
                        ha="left", va="center",
                        fontsize=FONT_BODY - 1, fontweight="bold",
                        color=badge_c, zorder=4)
                name_x = x_left + 0.46
            else:
                name_x = x_left + 0.14

            # Имя поля
            ax.text(name_x, cy, cn,
                    ha="left", va="center",
                    fontsize=FONT_BODY, color=name_c,
                    fontweight="normal", zorder=4)

            # Тип (справа) - серый
            ax.text(x_left + bw - 0.12, cy, ct,
                    ha="right", va="center",
                    fontsize=FONT_BODY - 1, color="#616161",
                    fontstyle="italic", zorder=4)

    # ── Стрелки FK (ЗА ТАБЛИЦАМИ, К PK ПОЛЯМ, ПРЯМЫЕ ПОД 90°)
    drawn = set()
    
    # Сначала рисуем ВСЕ стрелки (zorder=1, ЗА таблицами)
    for tname, info in schema.items():
        for fk in info["fks"]:
            to_table = fk["to_table"]
            if to_table not in schema:
                continue
            
            from_col = fk["from"]
            to_col = fk["to_col"]
            
            key = (min(tname, to_table), max(tname, to_table), from_col, to_col)
            if key in drawn:
                continue
            drawn.add(key)

            sx_l, sy_t, sw, sh = box_info[tname]
            tx_l, ty_t, tw, th = box_info[to_table]

            # Находим Y-координаты конкретных полей FK и PK
            source_cols = [c["name"] for c in schema[tname]["columns"]]
            target_cols = [c["name"] for c in schema[to_table]["columns"]]
            
            # Индекс поля FK в исходной таблице
            try:
                from_idx = source_cols.index(from_col)
                from_y = sy_t - HDR_H - (from_idx + 0.5) * ROW_H
            except ValueError:
                from_y = sy_t - sh / 2  # fallback к центру
            
            # Индекс поля PK в целевой таблице
            try:
                to_idx = target_cols.index(to_col)
                to_y = ty_t - HDR_H - (to_idx + 0.5) * ROW_H
            except ValueError:
                to_y = ty_t - th / 2  # fallback к центру

            # Определяем откуда/куда по горизонтали
            scx = sx_l + sw / 2
            tcx = tx_l + tw / 2
            
            if scx <= tcx:
                x_start = sx_l + sw  # правый край source
                x_end   = tx_l       # левый край target
            else:
                x_start = sx_l       # левый край source
                x_end   = tx_l + tw  # правый край target

            # Промежуточная точка для поворота 90°
            x_mid = (x_start + x_end) / 2
            
            # Рисуем ломаную линию: горизонталь → вертикаль → горизонталь
            # zorder=1 чтобы стрелки были ЗА таблицами
            ax.plot([x_start, x_mid], [from_y, from_y],
                    color="#1976D2", lw=2.0, solid_capstyle="round", zorder=1)
            ax.plot([x_mid, x_mid], [from_y, to_y],
                    color="#1976D2", lw=2.0, solid_capstyle="round", zorder=1)
            ax.plot([x_mid, x_end], [to_y, to_y],
                    color="#1976D2", lw=2.0, solid_capstyle="round", zorder=1)
            
            # СТРЕЛКА на конце (указывает на PK)
            arrow_len = 0.25
            if x_end > x_mid:
                arrow_start_x = x_end - arrow_len
            else:
                arrow_start_x = x_end + arrow_len
            
            ax.annotate(
                "",
                xy=(x_end, to_y),
                xytext=(arrow_start_x, to_y),
                arrowprops=dict(
                    arrowstyle="-|>",
                    color="#1976D2",
                    lw=2.0,
                    shrinkA=0,
                    shrinkB=0,
                    mutation_scale=15,
                ),
                zorder=1,  # ЗА таблицами
            )

    # ── Легенда (на белом фоне, увеличенные шрифты)
    legend_items = [
        mpatches.Patch(facecolor="#F57C00", edgecolor="none", label="PK — первичный ключ"),
        mpatches.Patch(facecolor="#0277BD", edgecolor="none", label="FK — внешний ключ"),
        Line2D([0], [0], color="#1976D2", lw=2.2, marker=">", markersize=8,
               label="Связь FK → PK"),
    ]
    ax.legend(
        handles=legend_items,
        loc="lower right",
        fontsize=10,
        facecolor="white",
        edgecolor="#424242",
        labelcolor="#212121",
        framealpha=0.97,
        borderpad=1.0,
    )

    fig.subplots_adjust(left=0.03, right=0.97, top=0.97, bottom=0.03)
    return fig


# ──────────────────────────────────────────────
#  GUI
# ──────────────────────────────────────────────

class ErDiagramTool:
    def __init__(self):
        self.root    = ctk.CTk()
        self.root.title("Генератор ER-диаграммы")
        self.root.geometry("800x620")
        self._schema = {}
        init_theme(self.root)
        init_ttk()
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self.root, fg_color=P["primary"],
                           corner_radius=0, height=48)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="ER-диаграмма базы данных",
                     font=ctk.CTkFont(family="Montserrat", size=14, weight="bold"),
                     text_color="white").pack(side="left", padx=14, pady=12)

        body = ctk.CTkFrame(self.root, fg_color=P["bg"], corner_radius=0)
        body.pack(fill="both", expand=True, padx=14, pady=10)

        # Путь к БД
        self._db_var  = self._path_row(body, "База данных:", DB_FILE,
                                       self._pick_db)
        # Путь вывода
        self._out_var = self._path_row(
            body, "Сохранить в:",
            os.path.join(os.path.dirname(DB_FILE), "er_diagram"),
            self._pick_out)

        # Цвет
        r3 = ctk.CTkFrame(body, fg_color=P["bg"], corner_radius=0)
        r3.pack(fill="x", pady=4)
        ctk.CTkLabel(r3, text="Цвет таблиц:", width=130,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     anchor="e").pack(side="left")
        self._color_var = tk.StringVar(value=P["primary"])
        ctk.CTkEntry(r3, textvariable=self._color_var, width=110,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     border_color=P["border"],
                     fg_color=P["surface"]).pack(side="left", padx=6)
        ctk.CTkLabel(r3, text="(hex, напр. #9C27B0)",
                     font=ctk.CTkFont(family="Montserrat", size=9),
                     text_color=P["text_muted"]).pack(side="left")

        # Кнопки
        btns = ctk.CTkFrame(body, fg_color=P["bg"], corner_radius=0)
        btns.pack(pady=10)
        for text, cmd, color, hover, tcolor in [
            ("Прочитать схему БД", self._load_schema,
             P["primary"], P["primary_hover"], "white"),
            ("Экспорт PDF + PNG",  self._export,
             P["accent"],  P["primary"],       "#1A1625"),
        ]:
            ctk.CTkButton(btns, text=text, command=cmd,
                          fg_color=color, hover_color=hover,
                          text_color=tcolor,
                          font=ctk.CTkFont(family="Montserrat",
                                           size=11, weight="bold"),
                          corner_radius=8, height=36,
                          width=195).pack(side="left", padx=6)

        # Таблица превью
        ctk.CTkLabel(body, text="Схема таблиц:",
                     font=ctk.CTkFont(family="Montserrat", size=10),
                     text_color=P["text_muted"]).pack(anchor="w", pady=(4, 2))
        tree_f = tk.Frame(body, bg=P["bg"])
        tree_f.pack(fill="both", expand=True)
        cols = ("Таблица", "Поле", "Тип", "PK", "FK", "NOT NULL")
        self._tree = ttk.Treeview(tree_f, columns=cols,
                                  show="headings", height=9)
        for c, w in zip(cols, (130, 150, 90, 40, 40, 70)):
            self._tree.heading(c, text=c)
            self._tree.column(c, width=w, minwidth=30)
        vsb = ttk.Scrollbar(tree_f, orient="vertical",
                            command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")

        self._status = ctk.CTkLabel(
            self.root, text="",
            font=ctk.CTkFont(family="Montserrat", size=9),
            text_color=P["text_muted"])
        self._status.pack(pady=4)

    def _path_row(self, parent, label, default, pick_cmd):
        row = ctk.CTkFrame(parent, fg_color=P["bg"], corner_radius=0)
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(row, text=label, width=130,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     anchor="e").pack(side="left")
        var = tk.StringVar(value=default)
        ctk.CTkEntry(row, textvariable=var, width=360,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     border_color=P["border"],
                     fg_color=P["surface"]).pack(side="left", padx=6)
        ctk.CTkButton(row, text="...", width=42, height=28,
                      command=pick_cmd,
                      fg_color=P["border"], hover_color=P["row_b"],
                      font=ctk.CTkFont(family="Montserrat", size=11),
                      corner_radius=6).pack(side="left")
        return var

    def _pick_db(self):
        p = filedialog.askopenfilename(
            filetypes=[("SQLite", "*.db *.sqlite"), ("Все", "*.*")])
        if p: self._db_var.set(p)

    def _pick_out(self):
        p = filedialog.asksaveasfilename(
            defaultextension="", initialfile="er_diagram",
            title="Базовое имя файла (без расширения)")
        if p:
            base = p.rsplit(".", 1)[0] if "." in os.path.basename(p) else p
            self._out_var.set(base)

    def _load_schema(self):
        db_path = self._db_var.get().strip()
        if not os.path.exists(db_path):
            messagebox.showwarning("Файл не найден",
                                   f"БД не найдена:\n{db_path}")
            return
        self._schema = read_schema(db_path)
        for i in self._tree.get_children():
            self._tree.delete(i)
        fk_map = {t: {fk["from"] for fk in info["fks"]}
                  for t, info in self._schema.items()}
        for tname, info in self._schema.items():
            fks = fk_map[tname]
            for col in info["columns"]:
                self._tree.insert("", "end", values=(
                    tname, col["name"], col["type"],
                    "+" if col["pk"]            else "",
                    "+" if col["name"] in fks   else "",
                    "+" if col["notnull"]        else "",
                ))
        self._status.configure(
            text=f"Загружено таблиц: {len(self._schema)}",
            text_color=P["success"])

    def _export(self):
        if not self._schema:
            messagebox.showwarning("Нет схемы",
                "Сначала нажмите «Прочитать схему БД»")
            return
        if not HAS_MPL:
            messagebox.showerror("matplotlib не установлен",
                                 "pip install matplotlib")
            return
        out   = self._out_var.get().strip()
        color = self._color_var.get().strip() or P["primary"]
        try:
            fig = draw_er(
                self._schema,
                primary_color=color,
                bg_color=P["bg"],
                surface_color=P["surface"],
                text_color=P["text"],
            )
            pdf_path = out + ".pdf"
            png_path = out + ".png"
            for path in (pdf_path, png_path):
                fig.savefig(path, dpi=120, bbox_inches="tight",
                            facecolor="white")  # Белый фон в файле
            plt.close(fig)
            self._status.configure(
                text=f"Сохранено: {os.path.basename(pdf_path)} + .png",
                text_color=P["success"])
            messagebox.showinfo("Готово",
                f"Диаграмма сохранена:\n{pdf_path}\n{png_path}")
        except Exception as e:
            messagebox.showerror("Ошибка экспорта", str(e))
            self._status.configure(text=f"Ошибка: {e}",
                                   text_color=P["error"])

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    ErDiagramTool().run()
