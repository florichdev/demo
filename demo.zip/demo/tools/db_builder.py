# -*- coding: utf-8 -*-
"""
tools/db_builder.py — GUI конструктор базы данных
Запуск: python tools/db_builder.py
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import customtkinter as ctk
from config import DB_FILE
from ui_theme import P, F, tk_face, init_theme, init_ttk, btn, lbl, entry, header_bar, card

COL_TYPES = ["INTEGER", "TEXT", "REAL", "NUMERIC",
             "BLOB", "DATE", "DATETIME", "BOOLEAN"]


def _cbtn(parent, text, cmd, color=None, hover=None, **kw):
    variant = "primary"
    if color == P.get("success"):
        variant = "success"
    elif color == P.get("error"):
        variant = "danger"
    elif color == P.get("accent"):
        variant = "accent"
    elif color == P.get("ghost"):
        variant = "ghost"
    return btn(parent, text, cmd, variant=variant, **kw)


# ─────────────────────────────────────────────
#  Диалог редактирования таблицы
# ─────────────────────────────────────────────

class TableEditor(ctk.CTkToplevel):
    def __init__(self, parent, existing=None):
        super().__init__(parent)
        self.result    = None
        self._cols     = []
        if existing:
            self._name_val = existing["name"]
            self._cols = [dict(c) for c in existing["columns"]]
        else:
            self._name_val = ""

        self.title("Редактор таблицы")
        self.geometry("800x580")
        self.resizable(True, True)
        self.transient(parent)
        self.grab_set()
        init_ttk()
        self._build()
        self._refresh_tree()

    def _build(self):
        # Шапка
        hdr = ctk.CTkFrame(self, fg_color=P["primary"],
                           corner_radius=0, height=46)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="Редактор структуры таблицы",
                     font=ctk.CTkFont(family="Montserrat", size=14, weight="bold"),
                     text_color="white").pack(side="left", padx=14, pady=10)

        body = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        body.pack(fill="both", expand=True, padx=12, pady=10)

        # Имя таблицы
        name_row = ctk.CTkFrame(body, fg_color=P["surface"],
                                corner_radius=10, height=48)
        name_row.pack(fill="x", pady=(0, 8)); name_row.pack_propagate(False)
        ctk.CTkLabel(name_row, text="Имя таблицы:",
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     text_color=P["text"]).pack(side="left", padx=14)
        self._name_var = tk.StringVar(value=self._name_val)
        ctk.CTkEntry(name_row, textvariable=self._name_var, width=280,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     border_color=P["border"], fg_color=P["surface"],
                     corner_radius=8).pack(side="left", padx=8)

        # Treeview
        tree_f = tk.Frame(body, bg=P["bg"])
        tree_f.pack(fill="both", expand=True)

        cols = ("Поле", "Тип", "PK", "NOT NULL", "По умолчанию")
        self._tree = ttk.Treeview(tree_f, columns=cols,
                                  show="headings", height=10)
        for c, w in zip(cols, (200, 110, 50, 80, 140)):
            self._tree.heading(c, text=c)
            self._tree.column(c, width=w, minwidth=40)
        vsb = ttk.Scrollbar(tree_f, orient="vertical",
                            command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")
        self._tree.bind("<<TreeviewSelect>>", self._pick_col)

        # Форма поля
        form = ctk.CTkFrame(body, fg_color=P["surface"],
                            corner_radius=10, border_width=1,
                            border_color=P["border"])
        form.pack(fill="x", pady=(8, 0))

        ctk.CTkLabel(form, text="Поле",
                     font=ctk.CTkFont(family="Montserrat", size=11, weight="bold"),
                     text_color=P["text"]).pack(anchor="w", padx=14, pady=(8, 4))

        row1 = ctk.CTkFrame(form, fg_color=P["surface"], corner_radius=0)
        row1.pack(fill="x", padx=14, pady=2)
        ctk.CTkLabel(row1, text="Название:", width=90,
                     font=ctk.CTkFont(family="Montserrat", size=11),
                     anchor="e").pack(side="left")
        self._f_name = ctk.CTkEntry(row1, width=200,
                                    font=ctk.CTkFont(family="Montserrat", size=11),
                                    border_color=P["border"],
                                    fg_color=P["surface"], corner_radius=8)
        self._f_name.pack(side="left", padx=6)

        ctk.CTkLabel(row1, text="Тип:",
                     font=ctk.CTkFont(family="Montserrat", size=11)).pack(
            side="left", padx=(16, 4))
        self._f_type = ctk.CTkComboBox(row1, values=COL_TYPES, width=130,
                                       state="readonly",
                                       font=ctk.CTkFont(family="Montserrat", size=11),
                                       border_color=P["border"])
        self._f_type.set("TEXT")
        self._f_type.pack(side="left")

        row2 = ctk.CTkFrame(form, fg_color=P["surface"], corner_radius=0)
        row2.pack(fill="x", padx=14, pady=4)
        self._pk_var = tk.BooleanVar()
        self._nn_var = tk.BooleanVar()
        ctk.CTkCheckBox(row2, text="PRIMARY KEY",
                        variable=self._pk_var,
                        font=ctk.CTkFont(family="Montserrat", size=11),
                        fg_color=P["primary"],
                        hover_color=P["primary_hover"]).pack(side="left", padx=6)
        ctk.CTkCheckBox(row2, text="NOT NULL",
                        variable=self._nn_var,
                        font=ctk.CTkFont(family="Montserrat", size=11),
                        fg_color=P["primary"],
                        hover_color=P["primary_hover"]).pack(side="left", padx=6)
        ctk.CTkLabel(row2, text="По умолчанию:",
                     font=ctk.CTkFont(family="Montserrat", size=11)).pack(
            side="left", padx=(16, 4))
        self._f_default = ctk.CTkEntry(row2, width=130,
                                       font=ctk.CTkFont(family="Montserrat", size=11),
                                       border_color=P["border"],
                                       fg_color=P["surface"], corner_radius=8)
        self._f_default.pack(side="left")

        # Кнопки управления полями
        fbtns = ctk.CTkFrame(form, fg_color=P["surface"], corner_radius=0)
        fbtns.pack(fill="x", padx=14, pady=(4, 12))

        _cbtn(fbtns, "+ Добавить поле",  self._add_col,
              color=P["success"], hover="#1B5E20").pack(side="left", padx=3)
        _cbtn(fbtns, "Обновить выбранное", self._update_col,
              color=P["primary"], hover=P["primary_hover"]).pack(side="left", padx=3)
        _cbtn(fbtns, "Удалить поле",     self._del_col,
              color=P["error"], hover="#7F0000").pack(side="left", padx=3)
        _cbtn(fbtns, "Вверх",    self._move_up,
              color="#78909C", hover="#546E7A", width=70).pack(side="left", padx=3)
        _cbtn(fbtns, "Вниз",    self._move_down,
              color="#78909C", hover="#546E7A", width=70).pack(side="left", padx=3)

        # Нижние кнопки
        bot = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        bot.pack(fill="x", padx=12, pady=(0, 10))
        _cbtn(bot, "Отмена", self.destroy,
              color="#78909C", hover="#546E7A", width=110).pack(side="left")
        _cbtn(bot, "Сохранить таблицу", self._finish,
              color=P["success"], hover="#1B5E20", width=180).pack(side="right")

    def _current_field(self):
        name = self._f_name.get().strip()
        if not name:
            messagebox.showwarning("Имя поля", "Введите название поля")
            return None
        return {
            "name":    name,
            "type":    self._f_type.get(),
            "pk":      self._pk_var.get(),
            "notnull": self._nn_var.get(),
            "default": self._f_default.get().strip(),
        }

    def _refresh_tree(self):
        for i in self._tree.get_children(): self._tree.delete(i)
        for c in self._cols:
            self._tree.insert("", "end", values=(
                c["name"], c["type"],
                "+" if c.get("pk")      else "",
                "+" if c.get("notnull") else "",
                c.get("default", ""),
            ))

    def _add_col(self):
        f = self._current_field()
        if not f: return
        if any(c["name"] == f["name"] for c in self._cols):
            messagebox.showwarning("Дубликат", f"Поле «{f['name']}» уже есть")
            return
        self._cols.append(f)
        self._refresh_tree()
        self._f_name.delete(0, "end")

    def _update_col(self):
        sel = self._tree.selection()
        if not sel: return
        f = self._current_field()
        if not f: return
        self._cols[self._tree.index(sel[0])] = f
        self._refresh_tree()

    def _del_col(self):
        sel = self._tree.selection()
        if not sel: return
        del self._cols[self._tree.index(sel[0])]
        self._refresh_tree()

    def _move_up(self):
        sel = self._tree.selection()
        if not sel: return
        i = self._tree.index(sel[0])
        if i > 0:
            self._cols[i-1], self._cols[i] = self._cols[i], self._cols[i-1]
            self._refresh_tree()

    def _move_down(self):
        sel = self._tree.selection()
        if not sel: return
        i = self._tree.index(sel[0])
        if i < len(self._cols) - 1:
            self._cols[i], self._cols[i+1] = self._cols[i+1], self._cols[i]
            self._refresh_tree()

    def _pick_col(self, _=None):
        sel = self._tree.selection()
        if not sel: return
        c = self._cols[self._tree.index(sel[0])]
        self._f_name.delete(0, "end");    self._f_name.insert(0, c["name"])
        self._f_type.set(c.get("type", "TEXT"))
        self._pk_var.set(c.get("pk", False))
        self._nn_var.set(c.get("notnull", False))
        self._f_default.delete(0, "end")
        if c.get("default"): self._f_default.insert(0, c["default"])

    def _finish(self):
        name = self._name_var.get().strip()
        if not name:
            messagebox.showwarning("Имя таблицы", "Введите имя таблицы"); return
        if not self._cols:
            messagebox.showwarning("Поля", "Добавьте хотя бы одно поле"); return
        self.result = {"name": name, "columns": self._cols}
        self.destroy()


# ─────────────────────────────────────────────
#  Главное окно конструктора
# ─────────────────────────────────────────────

class DbBuilderApp:
    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("Конструктор базы данных")
        self.root.geometry("960x680")
        self.root.resizable(True, True)
        init_theme(self.root)
        init_ttk()
        self._tables = []
        self._build()

    def _build(self):
        # Шапка
        hdr = ctk.CTkFrame(self.root, fg_color=P["primary"],
                           corner_radius=0, height=50)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="Конструктор базы данных",
                     font=ctk.CTkFont(family="Montserrat", size=15, weight="bold"),
                     text_color="white").pack(side="left", padx=16, pady=12)

        body = ctk.CTkFrame(self.root, fg_color=P["bg"], corner_radius=0)
        body.pack(fill="both", expand=True, padx=12, pady=10)

        # ── Левая: список таблиц
        left = ctk.CTkFrame(body, fg_color=P["surface"],
                            corner_radius=10, border_width=1,
                            border_color=P["border"], width=240)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        ctk.CTkLabel(left, text="Таблицы",
                     font=ctk.CTkFont(family="Montserrat", size=12, weight="bold"),
                     text_color=P["primary"]).pack(anchor="w", padx=14, pady=(10, 4))

        lf = tk.Frame(left, bg=P["surface"])
        lf.pack(fill="both", expand=True, padx=8)
        self._tlist = tk.Listbox(lf, font=tk_face("label"),
                                 bd=0, relief="flat", activestyle="dotbox",
                                 selectbackground=P["row_selected"],
                                 selectforeground=P["text"],
                                 bg=P["surface"], fg=P["text"])
        self._tlist.pack(fill="both", expand=True)
        self._tlist.bind("<<ListboxSelect>>", self._show_table)

        lb = ctk.CTkFrame(left, fg_color=P["surface"], corner_radius=0)
        lb.pack(fill="x", padx=8, pady=8)
        _cbtn(lb, "+ Таблица", self._new_table,
              color=P["success"], hover="#1B5E20",
              width=70).pack(side="left", padx=2)
        _cbtn(lb, "Изменить", self._edit_table,
              color=P["primary"], hover=P["primary_hover"],
              width=80).pack(side="left", padx=2)
        _cbtn(lb, "Удалить", self._del_table,
              color=P["error"], hover="#7F0000",
              width=70).pack(side="left", padx=2)

        # ── Правая: превью
        right = ctk.CTkFrame(body, fg_color=P["surface"],
                             corner_radius=10, border_width=1,
                             border_color=P["border"])
        right.pack(side="left", fill="both", expand=True)

        ctk.CTkLabel(right, text="Структура выбранной таблицы",
                     font=ctk.CTkFont(family="Montserrat", size=12, weight="bold"),
                     text_color=P["primary"]).pack(anchor="w", padx=14, pady=(10, 4))

        preview_f = tk.Frame(right, bg=P["surface"])
        preview_f.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        cols = ("Поле", "Тип", "PK", "NOT NULL", "По умолчанию")
        self._preview = ttk.Treeview(preview_f, columns=cols,
                                     show="headings", height=16)
        for c, w in zip(cols, (200, 110, 50, 80, 160)):
            self._preview.heading(c, text=c)
            self._preview.column(c, width=w)
        vsb = ttk.Scrollbar(preview_f, orient="vertical",
                            command=self._preview.yview)
        self._preview.configure(yscrollcommand=vsb.set)
        self._preview.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")

        # Нижние кнопки экспорта
        bot = ctk.CTkFrame(self.root, fg_color=P["bg"],
                           corner_radius=0, height=52)
        bot.pack(fill="x", padx=12, pady=(0, 10))
        bot.pack_propagate(False)

        _cbtn(bot, "Создать БД (SQLite)", self._create_db,
              color=P["primary"], hover=P["primary_hover"],
              width=170).pack(side="left", padx=4)
        _cbtn(bot, "Сгенерировать init_db.py", self._gen_script,
              color=P["accent"], hover="#E65100",
              width=200).pack(side="left", padx=4)
        _cbtn(bot, "Скопировать SQL", self._copy_sql,
              color="#78909C", hover="#546E7A",
              width=150).pack(side="left", padx=4)

        self._status = ctk.CTkLabel(bot, text="",
                                    font=ctk.CTkFont(family="Montserrat", size=10),
                                    text_color=P["text_muted"])
        self._status.pack(side="left", padx=10)

    # ── Управление таблицами

    def _new_table(self):
        dlg = TableEditor(self.root)
        self.root.wait_window(dlg)
        if dlg.result:
            if any(t["name"] == dlg.result["name"] for t in self._tables):
                messagebox.showwarning("Дубликат",
                    f"Таблица «{dlg.result['name']}» уже есть"); return
            self._tables.append(dlg.result)
            self._refresh_list()

    def _edit_table(self):
        idx = self._selected_idx()
        if idx is None: return
        dlg = TableEditor(self.root, existing=self._tables[idx])
        self.root.wait_window(dlg)
        if dlg.result:
            self._tables[idx] = dlg.result
            self._refresh_list()

    def _del_table(self):
        idx = self._selected_idx()
        if idx is None: return
        name = self._tables[idx]["name"]
        if messagebox.askyesno("Удалить", f"Удалить таблицу «{name}»?"):
            del self._tables[idx]
            self._refresh_list()
            for i in self._preview.get_children(): self._preview.delete(i)

    def _selected_idx(self):
        sel = self._tlist.curselection()
        if not sel:
            messagebox.showwarning("Не выбрано", "Выберите таблицу из списка")
            return None
        return sel[0]

    def _refresh_list(self):
        cur = self._tlist.curselection()
        self._tlist.delete(0, "end")
        for t in self._tables:
            self._tlist.insert("end", t["name"])
        if cur and cur[0] < len(self._tables):
            self._tlist.selection_set(cur[0])

    def _show_table(self, _=None):
        idx = self._selected_idx()
        if idx is None: return
        for i in self._preview.get_children(): self._preview.delete(i)
        for c in self._tables[idx]["columns"]:
            self._preview.insert("", "end", values=(
                c["name"], c["type"],
                "+" if c.get("pk")      else "",
                "+" if c.get("notnull") else "",
                c.get("default", ""),
            ))

    # ── Генерация SQL

    def _build_sql(self):
        parts = []
        for t in self._tables:
            col_defs = []
            for c in t["columns"]:
                d = f"    [{c['name']}] {c['type']}"
                if c.get("pk"):                      d += " PRIMARY KEY AUTOINCREMENT"
                if c.get("notnull") and not c.get("pk"): d += " NOT NULL"
                if c.get("default"):                 d += f" DEFAULT {c['default']}"
                col_defs.append(d)
            parts.append(
                f"CREATE TABLE IF NOT EXISTS [{t['name']}] (\n"
                + ",\n".join(col_defs)
                + "\n);\n"
            )
        return "\n".join(parts)

    def _create_db(self):
        if not self._tables:
            messagebox.showwarning("Нет таблиц", "Сначала создайте хотя бы одну таблицу"); return
        path = filedialog.asksaveasfilename(
            defaultextension=".db",
            filetypes=[("SQLite", "*.db"), ("Все", "*.*")],
            initialfile="database.db",
            title="Сохранить базу данных")
        if not path: return
        try:
            conn = sqlite3.connect(path)
            conn.executescript(self._build_sql())
            conn.commit(); conn.close()
            self._status.configure(
                text=f"БД создана: {os.path.basename(path)}",
                text_color=P["success"])
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _gen_script(self):
        if not self._tables:
            messagebox.showwarning("Нет таблиц", "Сначала создайте таблицы"); return
        path = filedialog.asksaveasfilename(
            defaultextension=".py",
            filetypes=[("Python", "*.py")],
            initialfile="init_db.py",
            title="Сохранить скрипт")
        if not path: return
        sql = self._build_sql()
        script = (
            '# -*- coding: utf-8 -*-\n'
            '"""Автоматически сгенерированный скрипт инициализации БД."""\n'
            'import sqlite3, os\n\n'
            'BASE_DIR = os.path.dirname(os.path.abspath(__file__))\n'
            'DB_PATH  = os.path.join(BASE_DIR, "database.db")\n\n'
            'SQL = """\n'
            f'{sql}\n'
            '"""\n\n'
            'if os.path.exists(DB_PATH):\n'
            '    if input("Пересоздать БД? (y/N): ").strip().lower() != "y":\n'
            '        print("Отмена."); exit()\n'
            '    os.remove(DB_PATH)\n\n'
            'conn = sqlite3.connect(DB_PATH)\n'
            'conn.executescript(SQL)\n'
            'conn.commit(); conn.close()\n'
            'print(f"БД создана: {DB_PATH}")\n'
        )
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(script)
            self._status.configure(
                text=f"Скрипт сохранён: {os.path.basename(path)}",
                text_color=P["success"])
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _copy_sql(self):
        sql = self._build_sql()
        if not sql.strip():
            messagebox.showwarning("Нет данных", "Нет таблиц для генерации SQL"); return
        self.root.clipboard_clear()
        self.root.clipboard_append(sql)
        self._status.configure(
            text="SQL скопирован в буфер обмена",
            text_color=P["success"])

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    DbBuilderApp().run()
