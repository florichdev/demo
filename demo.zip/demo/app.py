# ============================================================
#  app.py — главный модуль приложения (CustomTkinter)
#  НЕ ТРЕБУЕТ РЕДАКТИРОВАНИЯ
#  Запуск: python app.py
# ============================================================
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import customtkinter as ctk
import storage as db
from config import APP_TITLE, COMPANY_NAME, UI_MSG, MODULE3_SQL, MAX_LOGIN_ATTEMPTS, TYPEFACE
from ui_theme import (
    P, U, F, tk_face, init_theme,
    lbl, btn, entry, combo, card as mk_card, header_bar, toolbar, scroll_frame, tabview,
)


# ════════════════════════════════════════════
#  ВСПОМОГАТЕЛЬНЫЕ КОМПОНЕНТЫ
# ════════════════════════════════════════════

class StyledTree(tk.Frame):
    """Treeview с двумя скроллбарами."""
    def __init__(self, parent, **kw):
        super().__init__(parent, bg=P["bg"])
        self.tree = ttk.Treeview(self, show="headings", **kw)
        vsb = ttk.Scrollbar(self, orient="vertical", style="Vertical.TScrollbar",
                            command=self.tree.yview)
        hsb = ttk.Scrollbar(self, orient="horizontal", style="Horizontal.TScrollbar",
                            command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

    def set_cols(self, columns, width=140):
        self.tree["columns"] = columns
        for c in columns:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=width, minwidth=60)

    def fill(self, rows, columns):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for idx, row in enumerate(rows):
            vals = [row.get(c, "") for c in columns] if isinstance(row, dict) else list(row)
            tag = "odd" if idx % 2 else "even"
            self.tree.insert("", "end", values=vals, tags=(tag,))
        self.tree.tag_configure("even", background=P["row_a"])
        self.tree.tag_configure("odd", background=P["row_b"])


# ════════════════════════════════════════════
#  ДИАЛОГ РЕДАКТИРОВАНИЯ ЗАПИСИ
# ════════════════════════════════════════════

class RecordForm(ctk.CTkToplevel):
    def __init__(self, parent, table, row=None, on_saved=None):
        super().__init__(parent)
        self.table = table
        self.row = row
        self.on_saved = on_saved
        self.pk = db.primary_key_of(table)
        self.meta = db.columns_of(table)
        self.fields = {}

        mode = "Изменить запись" if row else "Добавить запись"
        self.title(f"{mode} — {table}")
        self.configure(fg_color=P["bg"])
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self._build()
        self.after(50, self._center)

    def _center(self):
        self.update_idletasks()
        px = self.master.winfo_rootx() + self.master.winfo_width() // 2
        py = self.master.winfo_rooty() + self.master.winfo_height() // 2
        w, h = self.winfo_reqwidth(), self.winfo_reqheight()
        self.geometry(f"{max(w, 520)}x{max(h, 220)}+{px - w // 2}+{py - h // 2}")

    def _build(self):
        hdr = header_bar(self)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        icon = "✏  " if self.row else "+ "
        lbl(hdr, f"{icon}{'Изменение' if self.row else 'Добавление'} записи  ({self.table})",
            style="caption", color=P["text_on_primary"]).pack(side="left", padx=18, pady=14)

        scroll = scroll_frame(self, width=500, height=400)
        scroll.pack(fill="both", expand=True, padx=18, pady=14)
        scroll.columnconfigure(0, weight=1, minsize=140)
        scroll.columnconfigure(1, weight=3)

        row_idx = 0
        for col in self.meta:
            name = col["name"]
            is_pk = col["pk"] > 0
            req = col["notnull"] and not is_pk
            if is_pk and not self.row:
                continue

            label = name + (" *" if req else "")
            lbl(scroll, label, anchor="w").grid(
                row=row_idx, column=0, sticky="w", pady=8, padx=(0, 12))

            e = entry(scroll, width=260)
            e.grid(row=row_idx, column=1, sticky="ew", pady=8)

            if self.row:
                val = self.row.get(name, "")
                e.insert(0, str(val) if val is not None else "")
                if is_pk:
                    e.configure(state="disabled", fg_color=P["row_b"], text_color=P["text_muted"])

            self.fields[name] = e
            row_idx += 1

        bf = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        bf.pack(fill="x", padx=18, pady=(0, 16))
        btn(bf, "Отмена", self.destroy, variant="ghost", width=120).pack(side="left")
        btn(bf, "Сохранить", self._save, variant="success", width=140).pack(side="right")

    def _save(self):
        data = {}
        for name, widget in self.fields.items():
            if str(widget.cget("state")) in ("disabled", "readonly"):
                continue
            val = widget.get().strip()
            col = next((c for c in self.meta if c["name"] == name), None)
            if col and col["notnull"] and val == "":
                messagebox.showerror("Обязательное поле", f"«{name}» не может быть пустым!")
                return
            if col and val:
                t = col["type"].upper()
                if "INT" in t:
                    try:
                        val = int(val)
                    except ValueError:
                        messagebox.showerror("Тип данных", f"«{name}» — целое число")
                        return
                elif any(x in t for x in ("REAL", "FLOAT", "NUMERIC")):
                    try:
                        val = float(val)
                    except ValueError:
                        messagebox.showerror("Тип данных", f"«{name}» — число с точкой")
                        return
            data[name] = val or None

        if self.row:
            ok, err = db.update_record(self.table, self.pk, self.row[self.pk], data)
        else:
            ok, err = db.insert_record(self.table, data)

        if ok:
            if self.on_saved:
                self.on_saved()
            self.destroy()
        else:
            messagebox.showerror("Ошибка БД", err)


# ════════════════════════════════════════════
#  ЭКРАН АВТОРИЗАЦИИ
# ════════════════════════════════════════════

class AuthScreen(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=P["bg"], corner_radius=0)
        self.app = app
        self._fails = 0
        self._build()

    def _build(self):
        wrap = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        wrap.place(relx=0.5, rely=0.5, anchor="center")

        login_card = mk_card(wrap, width=460, corner_radius=U["corner"])
        login_card.pack()
        login_card.grid_propagate(False)

        inner = ctk.CTkFrame(login_card, fg_color="transparent", corner_radius=0)
        inner.pack(fill="both", expand=True, padx=44, pady=36)

        lbl(inner, APP_TITLE, style="display", color=P["primary"]).pack(pady=(0, 6))
        lbl(inner, COMPANY_NAME, style="caption", color=P["text_muted"]).pack(pady=(0, 28))

        self._login_var = tk.StringVar()
        self._pass_var = tk.StringVar()

        for label_text, var, show in [("Логин", self._login_var, ""), ("Пароль", self._pass_var, "*")]:
            lbl(inner, label_text, anchor="w").pack(fill="x", pady=(0, 4))
            e = entry(inner, textvariable=var, show=show, width=360)
            e.pack(fill="x", pady=(0, 14))
            if label_text == "Логин":
                e.focus_set()

        self._notice = lbl(inner, "", style="small", wraplength=360)
        self._notice.pack(pady=(0, 8))

        btn(inner, "Войти", self._attempt, variant="primary",
            height=U["btn_height"], width=360, corner_radius=U["corner_btn"]).pack()

        self.master.bind("<Return>", lambda e: self._attempt())

    def _attempt(self):
        login = self._login_var.get().strip()
        pwd = self._pass_var.get()
        if not login or not pwd:
            self._msg(UI_MSG["fields_empty"], ok=False)
            return

        user, err = db.verify_credentials(login, pwd)
        if err == "blocked":
            self._msg(UI_MSG["login_block"], ok=False)
        elif err:
            self._fails += 1
            self._msg(f"{UI_MSG['login_fail']} ({self._fails}/{MAX_LOGIN_ATTEMPTS})", ok=False)
        else:
            self._msg(UI_MSG["login_ok"], ok=True)
            self.after(600, lambda: self.app.open_main(user))

    def _msg(self, text, ok=True):
        self._notice.configure(text=text, text_color=P["success"] if ok else P["error"])


# ════════════════════════════════════════════
#  ПРОСМОТР ДАННЫХ
# ════════════════════════════════════════════

class DataView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=P["bg"], corner_radius=0)
        self._cols = []
        self._rows = []
        self._build()

    def _build(self):
        ctrl = toolbar(self)
        ctrl.pack(fill="x", padx=U["padding"], pady=(U["padding"], 8))
        ctrl.pack_propagate(False)

        lbl(ctrl, "Таблица:", style="caption").pack(side="left", padx=(16, 6))
        self._table_var = tk.StringVar()
        self._combo = combo(ctrl, variable=self._table_var, values=[], width=240,
                            command=lambda _: self._load(), state="readonly")
        self._combo.pack(side="left", padx=4)

        btn(ctrl, "↻", self._refresh_list, variant="ghost", width=40).pack(side="left", padx=4)

        lbl(ctrl, "Поиск:", style="caption").pack(side="left", padx=(20, 6))
        self._q = tk.StringVar()
        self._q.trace_add("write", lambda *_: self._filter())
        entry(ctrl, textvariable=self._q, width=180).pack(side="left", padx=4)

        for text, cmd, variant in [
            ("+ Добавить", self._add, "success"),
            ("Изменить", self._edit, "primary"),
            ("Удалить", self._delete, "danger"),
            ("Экспорт CSV", self._export, "accent"),
        ]:
            btn(ctrl, text, cmd, variant=variant,
                width=118 if "Экспорт" in text else 96).pack(side="right", padx=4)

        self._count_lbl = lbl(self, "", style="small", color=P["text_muted"])
        self._count_lbl.pack(anchor="w", padx=20)

        tree_frame = tk.Frame(self, bg=P["bg"])
        tree_frame.pack(fill="both", expand=True, padx=U["padding"], pady=(0, U["padding"]))
        self._tree = StyledTree(tree_frame)
        self._tree.pack(fill="both", expand=True)
        self._refresh_list()

    def _refresh_list(self):
        tables = db.user_tables()
        self._combo.configure(values=tables)
        if tables:
            if self._table_var.get() not in tables:
                self._combo.set(tables[0])
            self._load()

    def _load(self, _=None):
        t = self._table_var.get()
        if not t:
            return
        self._cols, self._rows = db.fetch_table(t)
        self._q.set("")
        self._filter()

    def _filter(self):
        q = self._q.get().lower()
        filtered = [r for r in self._rows if not q or any(q in str(v).lower() for v in r.values())]
        self._tree.set_cols(self._cols)
        self._tree.fill(filtered, self._cols)
        self._count_lbl.configure(text=f"Показано {len(filtered)} из {len(self._rows)} записей")

    def _selected(self):
        sel = self._tree.tree.selection()
        if not sel:
            messagebox.showwarning("Не выбрано", "Выберите строку в таблице")
            return None
        return dict(zip(self._cols, self._tree.tree.item(sel[0], "values")))

    def _add(self):
        t = self._table_var.get()
        if t:
            RecordForm(self, t, on_saved=self._load)

    def _edit(self):
        t = self._table_var.get()
        if not t:
            return
        row = self._selected()
        if row:
            RecordForm(self, t, row=row, on_saved=self._load)

    def _delete(self):
        t = self._table_var.get()
        if not t:
            return
        row = self._selected()
        if not row:
            return
        pk = db.primary_key_of(t)
        if messagebox.askyesno("Удалить запись", "Вы уверены, что хотите удалить эту запись?"):
            ok, err = db.delete_record(t, pk, row.get(pk))
            if ok:
                self._load()
            else:
                messagebox.showerror("Ошибка БД", err)

    def _export(self):
        t = self._table_var.get()
        if not t:
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile=f"{t}.csv")
        if path:
            ok, err = db.export_csv(t, path)
            if ok:
                messagebox.showinfo("Экспорт завершён", f"Файл сохранён:\n{path}")
            else:
                messagebox.showerror("Ошибка экспорта", err)


# ════════════════════════════════════════════
#  SQL-ЗАПРОСЫ (МОДУЛЬ 3)
# ════════════════════════════════════════════

class SqlQueryView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=P["bg"], corner_radius=0)
        self._build()

    def _build(self):
        lbl(self, "Аналитический SQL-запрос", style="title", color=P["primary"]).pack(
            anchor="w", padx=U["padding"], pady=(14, 6))

        editor = mk_card(self)
        editor.pack(fill="x", padx=U["padding"], pady=(0, 10))

        mono = TYPEFACE["mono"]
        self._sql = tk.Text(
            editor, font=mono, height=11,
            bg=P["input_bg"], fg=P["text"],
            insertbackground=P["primary_soft"],
            selectbackground=P["row_selected"],
            selectforeground=P["text_on_primary"],
            relief="flat", wrap="word", padx=12, pady=10,
            highlightthickness=1,
            highlightbackground=P["border"],
            highlightcolor=P["border_focus"],
        )
        self._sql.pack(fill="x", padx=10, pady=10)
        self._sql.insert("1.0", MODULE3_SQL.strip())

        ctrl = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        ctrl.pack(fill="x", padx=U["padding"], pady=(0, 8))
        btn(ctrl, "▶  Выполнить", self._run, variant="accent", width=150).pack(side="left")
        self._status = lbl(ctrl, "", style="small", color=P["text_muted"])
        self._status.pack(side="left", padx=14)

        tree_frame = tk.Frame(self, bg=P["bg"])
        tree_frame.pack(fill="both", expand=True, padx=U["padding"], pady=(0, U["padding"]))
        self._tree = StyledTree(tree_frame)
        self._tree.pack(fill="both", expand=True)

    def _run(self):
        query = self._sql.get("1.0", "end").strip()
        if not query:
            self._status.configure(text="Введите SQL-запрос", text_color=P["error"])
            return

        cols, rows, msg = db.run_sql(query)
        if msg and cols is None:
            self._tree.set_cols([])
            self._tree.fill([], [])
            self._status.configure(text=msg, text_color=P["error"])
            return

        if not cols:
            self._tree.set_cols([])
            self._tree.fill([], [])
            self._status.configure(text=msg or "Запрос выполнен", text_color=P["success"])
            return

        self._tree.set_cols(cols)
        self._tree.fill([dict(zip(cols, r)) for r in rows], cols)
        self._status.configure(text=f"Строк: {len(rows)}", text_color=P["success"])


# ════════════════════════════════════════════
#  УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ
# ════════════════════════════════════════════

class UsersPanel(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=P["bg"], corner_radius=0)
        self.app = app
        self._sel_uid = None
        self._build()
        self._reload()

    def _build(self):
        left = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0)
        right = ctk.CTkFrame(self, fg_color=P["bg"], corner_radius=0, width=300)
        left.pack(side="left", fill="both", expand=True, padx=(12, 6), pady=12)
        right.pack(side="right", fill="y", padx=(6, 12), pady=12)

        lbl(left, "Пользователи", style="title", color=P["primary"]).pack(anchor="w", pady=(0, 8))

        tree_f = tk.Frame(left, bg=P["bg"])
        tree_f.pack(fill="both", expand=True)
        cols = ("id", "Логин", "Роль", "Заблок.")
        self._utree = ttk.Treeview(tree_f, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (50, 200, 200, 80)):
            self._utree.heading(c, text=c)
            self._utree.column(c, width=w)
        vsb = ttk.Scrollbar(tree_f, orient="vertical", style="Vertical.TScrollbar",
                            command=self._utree.yview)
        self._utree.configure(yscrollcommand=vsb.set)
        self._utree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="left", fill="y")
        self._utree.bind("<<TreeviewSelect>>", self._pick)

        form = mk_card(left)
        form.pack(fill="x", pady=(12, 0))
        lbl(form, "Данные пользователя", style="caption").pack(anchor="w", padx=16, pady=(12, 6))

        fields_f = ctk.CTkFrame(form, fg_color="transparent", corner_radius=0)
        fields_f.pack(fill="x", padx=16)
        self._f_login = self._field_row(fields_f, "Логин:")
        self._f_pass = self._field_row(fields_f, "Пароль:")

        role_row = ctk.CTkFrame(fields_f, fg_color="transparent", corner_radius=0)
        role_row.pack(fill="x", pady=6)
        lbl(role_row, "Роль:", width=84, anchor="e").pack(side="left")
        self._f_role = combo(role_row, values=[], width=240, state="readonly")
        self._f_role.pack(side="left", padx=(8, 0))

        btns_f = ctk.CTkFrame(form, fg_color="transparent", corner_radius=0)
        btns_f.pack(fill="x", padx=16, pady=(10, 14))
        for text, cmd, variant in [
            ("+ Добавить", self._add_user, "success"),
            ("Сохранить", self._save_user, "primary"),
            ("Удалить", self._del_user, "danger"),
            ("Разблокировать", self._unblock, "accent"),
        ]:
            btn(btns_f, text, cmd, variant=variant, width=112).pack(side="left", padx=3)

        self._umsg = lbl(form, "", style="small")
        self._umsg.pack(pady=(0, 10))

        lbl(right, "Роли", style="title", color=P["primary"]).pack(anchor="w", pady=(0, 8))
        self._rlist = tk.Listbox(
            right, font=tk_face("label"), bd=0, highlightthickness=1,
            highlightbackground=P["border"], highlightcolor=P["border_focus"],
            height=14, selectbackground=P["row_selected"],
            selectforeground=P["text_on_primary"],
            bg=P["surface"], fg=P["text"], activestyle="none",
        )
        self._rlist.pack(fill="both", expand=True)

        rform = mk_card(right)
        rform.pack(fill="x", pady=(10, 0))
        lbl(rform, "Название роли:", style="small", color=P["text_muted"]).pack(
            anchor="w", padx=12, pady=(10, 4))
        self._f_role_name = entry(rform, width=260)
        self._f_role_name.pack(padx=12, pady=(0, 8))

        rb = ctk.CTkFrame(rform, fg_color="transparent", corner_radius=0)
        rb.pack(fill="x", padx=12, pady=(0, 12))
        btn(rb, "+ Создать", self._add_role, variant="success", width=118).pack(side="left", padx=3)
        btn(rb, "Удалить", self._del_role, variant="danger", width=118).pack(side="left", padx=3)

    def _field_row(self, parent, label):
        row = ctk.CTkFrame(parent, fg_color="transparent", corner_radius=0)
        row.pack(fill="x", pady=5)
        lbl(row, label, width=84, anchor="e").pack(side="left")
        e = entry(row, width=240)
        e.pack(side="left", padx=(8, 0))
        return e

    def _reload(self):
        for i in self._utree.get_children():
            self._utree.delete(i)
        for u in db.list_users():
            bl = "Да" if u["is_blocked"] else "—"
            tag = "blocked" if u["is_blocked"] else ""
            self._utree.insert("", "end", values=(u["id"], u["login"], u["role"], bl), tags=(tag,))
        self._utree.tag_configure("blocked", background=P["user_blocked"])

        roles = db.list_roles()
        self._rlist.delete(0, "end")
        for r in roles:
            self._rlist.insert("end", r)
        self._f_role.configure(values=roles)
        if roles:
            self._f_role.set(roles[0])

    def _pick(self, _=None):
        sel = self._utree.selection()
        if not sel:
            return
        v = self._utree.item(sel[0], "values")
        self._sel_uid = v[0]
        self._f_login.delete(0, "end")
        self._f_login.insert(0, v[1])
        self._f_role.set(v[2])
        self._f_pass.delete(0, "end")

    def _notice(self, text, ok=True):
        self._umsg.configure(text=text, text_color=P["success"] if ok else P["error"])

    def _add_user(self):
        login = self._f_login.get().strip()
        pwd = self._f_pass.get().strip()
        role = self._f_role.get()
        if not login or not pwd:
            self._notice("Введите логин и пароль", ok=False)
            return
        ok, err = db.create_user(login, pwd, role)
        self._notice("Пользователь создан" if ok else err, ok=ok)
        if ok:
            self._reload()

    def _save_user(self):
        if not self._sel_uid:
            self._notice("Выберите пользователя", ok=False)
            return
        db.modify_user(
            int(self._sel_uid),
            login=self._f_login.get().strip(),
            password=self._f_pass.get().strip() or None,
            role=self._f_role.get(),
        )
        self._notice("Изменения сохранены")
        self._reload()

    def _del_user(self):
        if not self._sel_uid:
            self._notice("Выберите пользователя", ok=False)
            return
        if int(self._sel_uid) == self.app.user.get("id"):
            self._notice("Нельзя удалить текущего пользователя", ok=False)
            return
        if messagebox.askyesno("Удалить пользователя", "Вы уверены?"):
            db.remove_user(int(self._sel_uid))
            self._sel_uid = None
            self._notice("Пользователь удалён")
            self._reload()

    def _unblock(self):
        if not self._sel_uid:
            self._notice("Выберите пользователя", ok=False)
            return
        db.modify_user(int(self._sel_uid), is_blocked=0)
        self._notice("Аккаунт разблокирован")
        self._reload()

    def _add_role(self):
        name = self._f_role_name.get().strip()
        if not name:
            return
        ok, err = db.create_role(name)
        if ok:
            self._f_role_name.delete(0, "end")
            self._reload()
        else:
            messagebox.showerror("Ошибка", err)

    def _del_role(self):
        sel = self._rlist.curselection()
        if not sel:
            return
        name = self._rlist.get(sel[0])
        if name in ("Администратор", "Пользователь"):
            messagebox.showwarning("Нельзя", "Стандартные роли удалять нельзя")
            return
        if messagebox.askyesno("Удалить роль", f"Удалить «{name}»?"):
            ok, err = db.remove_role(name)
            if ok:
                self._reload()
            else:
                messagebox.showerror("Ошибка", err)


# ════════════════════════════════════════════
#  ГЛАВНОЕ ОКНО
# ════════════════════════════════════════════

class MainShell(ctk.CTkFrame):
    def __init__(self, parent, app, user):
        super().__init__(parent, fg_color=P["bg"], corner_radius=0)
        self.app = app
        self.user = user
        self._build()

    def _build(self):
        hdr = header_bar(self)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        lbl(hdr, f"  {APP_TITLE}  —  {COMPANY_NAME}",
            style="caption", color=P["text_on_primary"]).pack(side="left", padx=16)

        lbl(hdr, f"{self.user['login']}  ({self.user['role']})",
            style="label", color=P["text_on_primary"]).pack(side="right", padx=16)

        btn(hdr, "Выход", self.app.go_login, variant="danger",
            width=90, height=36).pack(side="right", padx=10)

        tabs = tabview(self)
        tabs.pack(fill="both", expand=True, padx=12, pady=12)

        tab_data = tabs.add("  Данные  ")
        DataView(tab_data).pack(fill="both", expand=True)

        tab_sql = tabs.add("  SQL  ")
        SqlQueryView(tab_sql).pack(fill="both", expand=True)

        if self.user.get("role") == "Администратор":
            tab_users = tabs.add("  Пользователи  ")
            UsersPanel(tab_users, self.app).pack(fill="both", expand=True)


# ════════════════════════════════════════════
#  ТОЧКА ВХОДА
# ════════════════════════════════════════════

class AppRunner:
    def __init__(self):
        self.root = ctk.CTk()
        self.root.title(APP_TITLE)
        self.root.geometry("1366x768")
        self.root.minsize(1100, 700)
        init_theme(self.root)

        try:
            self.root.state("zoomed")
        except Exception:
            try:
                self.root.attributes("-zoomed", True)
            except Exception:
                pass

        db.bootstrap()
        self._frame = None
        self.user = None
        self.go_login()

    def _switch(self, cls, *args):
        if self._frame:
            self._frame.destroy()
        self._frame = cls(self.root, *args)
        self._frame.pack(fill="both", expand=True)

    def go_login(self):
        self._switch(AuthScreen, self)

    def open_main(self, user):
        self.user = user
        self._switch(MainShell, self, user)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    AppRunner().run()
