# -*- coding: utf-8 -*-
"""Локальная загрузка Montserrat — без установки в систему."""
import ctypes
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
FONT_DIR = BASE_DIR / "fonts"
FONT_FAMILY = "Montserrat"

FONT_FILES = (
    "Montserrat-Regular.ttf",
    "Montserrat-Medium.ttf",
    "Montserrat-SemiBold.ttf",
    "Montserrat-Bold.ttf",
)

_loaded = False


def _load_windows(path: Path) -> bool:
    gdi = getattr(ctypes.windll, "gdi32", None)
    if gdi is None:
        return False
    FR_PRIVATE = 0x10
    return bool(gdi.AddFontResourceExW(str(path.resolve()), FR_PRIVATE, 0))


def _load_linux(path: Path) -> bool:
    try:
        from matplotlib import font_manager
        font_manager.fontManager.addfont(str(path))
        return True
    except Exception:
        return False


def load_montserrat() -> str:
    """Регистрирует TTF из папки fonts/ для текущего процесса."""
    global _loaded
    if _loaded:
        return FONT_FAMILY

    missing = []
    for name in FONT_FILES:
        path = FONT_DIR / name
        if not path.exists():
            missing.append(name)
            continue
        if sys.platform == "win32":
            _load_windows(path)
        elif sys.platform.startswith("linux"):
            _load_linux(path)
        else:
            os.environ.setdefault("TKFONT", str(path))

    if missing:
        print(f"[fonts] Не найдены: {', '.join(missing)} в {FONT_DIR}")

    _loaded = True
    return FONT_FAMILY
