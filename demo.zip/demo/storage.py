# ============================================================
#  storage.py — модуль работы с БД
#  НЕ ТРЕБУЕТ РЕДАКТИРОВАНИЯ
# ============================================================
import sqlite3
import csv
from config import DB_FILE, USERS_TABLE


def connect(path=DB_FILE):
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


# ────────────────────────────────────────────
#  ИНИЦИАЛИЗАЦИЯ
# ────────────────────────────────────────────

def bootstrap():
    """Создаёт системные таблицы при первом запуске."""
    conn = connect()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS UserRoles (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )
    """)
    for r in ("Администратор", "Пользователь"):
        conn.execute("INSERT OR IGNORE INTO UserRoles (name) VALUES (?)", (r,))

    conn.executescript(f"""
        CREATE TABLE IF NOT EXISTS {USERS_TABLE} (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            login           TEXT UNIQUE NOT NULL,
            password        TEXT NOT NULL,
            role            TEXT NOT NULL DEFAULT 'Пользователь',
            is_blocked      INTEGER DEFAULT 0,
            failed_attempts INTEGER DEFAULT 0
        );
    """)

    cnt = conn.execute(f"SELECT COUNT(*) FROM {USERS_TABLE}").fetchone()[0]
    if cnt == 0:
        conn.execute(
            f"INSERT INTO {USERS_TABLE} (login, password, role) VALUES (?,?,?)",
            ("admin", "admin", "Администратор"),
        )

    conn.commit()
    conn.close()


# ────────────────────────────────────────────
#  АВТОРИЗАЦИЯ
# ────────────────────────────────────────────

def verify_credentials(login, password):
    """
    Возвращает (user_dict, None) при успехе
    или (None, "not_found"|"blocked"|"wrong") при ошибке.
    """
    from config import MAX_LOGIN_ATTEMPTS
    conn = connect()
    row = conn.execute(
        f"SELECT * FROM {USERS_TABLE} WHERE login=?", (login,)
    ).fetchone()

    if not row:
        conn.close()
        return None, "not_found"

    if row["is_blocked"]:
        conn.close()
        return None, "blocked"

    if row["password"] != password:
        attempts = row["failed_attempts"] + 1
        blocked = 1 if attempts >= MAX_LOGIN_ATTEMPTS else 0
        conn.execute(
            f"UPDATE {USERS_TABLE} SET failed_attempts=?, is_blocked=? WHERE id=?",
            (attempts, blocked, row["id"]),
        )
        conn.commit()
        conn.close()
        return None, "blocked" if blocked else "wrong"

    conn.execute(
        f"UPDATE {USERS_TABLE} SET failed_attempts=0 WHERE id=?", (row["id"],)
    )
    conn.commit()
    user = dict(row)
    conn.close()
    return user, None


# ────────────────────────────────────────────
#  ПОЛЬЗОВАТЕЛИ
# ────────────────────────────────────────────

def list_users():
    conn = connect()
    rows = conn.execute(
        f"SELECT id, login, role, is_blocked FROM {USERS_TABLE}"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_user(login, password, role):
    conn = connect()
    if conn.execute(f"SELECT id FROM {USERS_TABLE} WHERE login=?", (login,)).fetchone():
        conn.close()
        return False, "Логин уже занят"
    conn.execute(
        f"INSERT INTO {USERS_TABLE} (login, password, role) VALUES (?,?,?)",
        (login, password, role),
    )
    conn.commit()
    conn.close()
    return True, None


def modify_user(uid, login=None, password=None, role=None, is_blocked=None):
    conn = connect()
    fields, vals = [], []
    if login     is not None: fields.append("login=?");          vals.append(login)
    if password  is not None: fields.append("password=?");       vals.append(password)
    if role      is not None: fields.append("role=?");           vals.append(role)
    if is_blocked is not None:
        fields.append("is_blocked=?"); vals.append(is_blocked)
        if is_blocked == 0:
            fields.append("failed_attempts=0")
    if fields:
        vals.append(uid)
        conn.execute(f"UPDATE {USERS_TABLE} SET {', '.join(fields)} WHERE id=?", vals)
        conn.commit()
    conn.close()


def remove_user(uid):
    conn = connect()
    conn.execute(f"DELETE FROM {USERS_TABLE} WHERE id=?", (uid,))
    conn.commit()
    conn.close()


def list_roles():
    conn = connect()
    rows = conn.execute("SELECT name FROM UserRoles").fetchall()
    conn.close()
    return [r["name"] for r in rows]


def create_role(name):
    conn = connect()
    try:
        conn.execute("INSERT INTO UserRoles (name) VALUES (?)", (name,))
        conn.commit()
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def remove_role(name):
    conn = connect()
    try:
        conn.execute("DELETE FROM UserRoles WHERE name=?", (name,))
        conn.commit()
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


# ────────────────────────────────────────────
#  ДИНАМИЧЕСКОЕ ЧТЕНИЕ ТАБЛИЦ
# ────────────────────────────────────────────

_SYSTEM = {USERS_TABLE, "sqlite_sequence", "UserRoles"}


def user_tables():
    """Имена пользовательских таблиц (без системных)."""
    conn = connect()
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    conn.close()
    return [r["name"] for r in rows if r["name"] not in _SYSTEM]


def fetch_table(table, limit=5000):
    conn = connect()
    try:
        cur = conn.execute(f"SELECT * FROM [{table}] LIMIT ?", (limit,))
        cols = [d[0] for d in cur.description]
        rows = [dict(r) for r in cur.fetchall()]
        return cols, rows
    except Exception:
        return [], []
    finally:
        conn.close()


def primary_key_of(table):
    conn = connect()
    try:
        for r in conn.execute(f"PRAGMA table_info([{table}])").fetchall():
            if r["pk"] > 0:
                return r["name"]
        return "rowid"
    finally:
        conn.close()


def columns_of(table):
    """Возвращает список {name, type, notnull, pk}."""
    conn = connect()
    try:
        return [dict(r) for r in
                conn.execute(f"PRAGMA table_info([{table}])").fetchall()]
    finally:
        conn.close()


def foreign_keys_of(table):
    conn = connect()
    try:
        return [dict(r) for r in
                conn.execute(f"PRAGMA foreign_key_list([{table}])").fetchall()]
    finally:
        conn.close()


# ────────────────────────────────────────────
#  CRUD
# ────────────────────────────────────────────

def insert_record(table, data):
    conn = connect()
    try:
        cols = list(data.keys())
        q = (
            f"INSERT INTO [{table}] ({', '.join(f'[{c}]' for c in cols)}) "
            f"VALUES ({', '.join(['?']*len(cols))})"
        )
        conn.execute(q, list(data.values()))
        conn.commit()
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def update_record(table, pk_col, pk_val, data):
    conn = connect()
    try:
        sets = [f"[{k}]=?" for k in data.keys()]
        vals = list(data.values()) + [pk_val]
        conn.execute(
            f"UPDATE [{table}] SET {', '.join(sets)} WHERE [{pk_col}]=?", vals
        )
        conn.commit()
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def delete_record(table, pk_col, pk_val):
    conn = connect()
    try:
        conn.execute(f"DELETE FROM [{table}] WHERE [{pk_col}]=?", (pk_val,))
        conn.commit()
        return True, None
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def run_sql(query):
    """Выполнить произвольный SQL. Возвращает (cols, rows, message)."""
    conn = connect()
    try:
        cur = conn.execute(query)
        if cur.description:
            cols = [d[0] for d in cur.description]
            rows = [list(r) for r in cur.fetchall()]
            conn.commit()
            return cols, rows, None
        conn.commit()
        return [], [], f"Выполнено. Затронуто строк: {cur.rowcount}"
    except Exception as e:
        return None, None, str(e)
    finally:
        conn.close()


# ────────────────────────────────────────────
#  ЭКСПОРТ
# ────────────────────────────────────────────

def export_csv(table, filepath):
    cols, rows = fetch_table(table)
    if not cols:
        return False, "Таблица пуста или не найдена"
    try:
        with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(cols)
            for r in rows:
                w.writerow([r.get(c, "") for c in cols])
        return True, None
    except Exception as e:
        return False, str(e)
