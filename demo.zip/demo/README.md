# MyExamApp — шпаргалка на экзамен

Python + CustomTkinter + SQLite.  
**Логин:** `admin` / `admin`

---

## Быстрый старт

```powershell
cd MyExamApp
pip install -r requirements.txt
python app.py
```

---

## Структура проекта

| Файл / папка | Назначение | Трогать на экзамене? |
|---|---|---|
| `config.py` | Название, организация, SQL модуль 3, цвета | **ДА — главный файл** |
| `init_db.py` | SQL-схема и тестовые данные | **ДА — если БД через код** |
| `database.db` | Файл базы данных | создаётся автоматически |
| `app.py` | GUI приложения | нет |
| `storage.py` | Работа с SQLite | нет |
| `ui_theme.py` | Тёмная тема, кнопки, шрифты | нет |
| `fonts.py` | Загрузка Montserrat | нет |
| `fonts/` | 4 файла `.ttf` | нет |
| `tools/db_builder.py` | GUI конструктор БД | запускать |
| `tools/er_diagram.py` | ER-диаграмма → PDF + PNG | запускать |
| `tools/generate_docs.py` | Документация → TXT + PDF | запускать |

---

## Чеклист на экзамене (по порядку)

### 1. Прочитать ТЗ и настроить `config.py`

```python
APP_TITLE    = "..."      # название из ТЗ
COMPANY_NAME = 'ООО «...»'

MODULE3_SQL = """
SELECT ...                 # аналитический запрос из модуля 3
"""

# Смена акцента — только две строки в PALETTE:
"primary":       "#7C4DFF",
"primary_hover": "#651FFF",
```

**Пресеты primary / primary_hover:**

| Тема | primary | primary_hover |
|---|---|---|
| Фиолетовый (сейчас) | `#7C4DFF` | `#651FFF` |
| Синий | `#1565C0` | `#1E88E5` |
| Зелёный | `#2E7D32` | `#388E3C` |
| Красный | `#B71C1C` | `#E53935` |

### 2. Создать базу данных

**Способ A — GUI (быстрее):**
```powershell
python tools/db_builder.py
```
«+ Таблица» → поля → FK → «Создать БД».

**Способ B — код:**
1. Отредактировать `SQL_SCHEMA` и `SQL_DATA` в `init_db.py`
2. Запустить:
```powershell
python init_db.py
```

### 3. Проверить приложение

```powershell
python app.py
```

Проверить:
- [ ] Вход admin/admin
- [ ] Вкладка **Данные** — CRUD, поиск, экспорт CSV
- [ ] Вкладка **SQL** — запрос из `MODULE3_SQL` выполняется
- [ ] Вкладка **Пользователи** (только admin) — добавить/удалить

### 4. Сгенерировать документы

```powershell
python tools/er_diagram.py      # ER → PDF + PNG
python tools/generate_docs.py   # документация → TXT + PDF
```

### 5. Сдать / залить

Упаковать всю папку `MyExamApp` (с `fonts/`, `database.db`, документами).

---

## Что умеет приложение

| Модуль | Функция |
|---|---|
| Авторизация | Логин/пароль, блокировка после 3 ошибок |
| Данные | Универсальный CRUD по любой таблице БД |
| SQL | Выполнение аналитического запроса (модуль 3) |
| Пользователи | Только роль «Администратор» |
| Экспорт | CSV из любой таблицы |

Системные таблицы (`Пользователи`, `UserRoles`) создаются автоматически при первом запуске.

---

## Зависимости

```
customtkinter
matplotlib      — ER-диаграммы
reportlab       — PDF документация
```

Установка: `pip install -r requirements.txt`

---

## Частые проблемы

| Проблема | Решение |
|---|---|
| Шрифт не тот | Проверить папку `fonts/` — 4 файла `.ttf` |
| SQL-вкладка пустая | Заполнить `MODULE3_SQL` в `config.py` |
| Таблиц нет в списке | Запустить `init_db.py` или `db_builder.py` |
| Ошибка FK при INSERT | Сначала создать родительскую запись |
| Заблокирован admin | Удалить `database.db` и пересоздать БД |

---

## Минимум для нового ТЗ

1. `config.py` — название, SQL, цвет  
2. БД — `db_builder.py` или `init_db.py`  
3. `python app.py` — проверка  
4. `er_diagram.py` + `generate_docs.py` — документы  

**Не редактировать:** `app.py`, `storage.py`, `ui_theme.py`, `fonts.py`
