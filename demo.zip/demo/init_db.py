#!/usr/bin/env python3
"""
init_db.py — создание тестовой базы данных
Запуск: python init_db.py

На экзамене:
  1. Замени SQL_SCHEMA под новые таблицы из ТЗ
  2. Замени SQL_DATA под тестовые данные
  3. Запусти этот скрипт
"""
import sqlite3
import os
from config import DB_FILE

# ──────────────────────────────────────────────
#  МЕНЯЙ ЭТО ПОД НОВОЕ ТЗ:
# ──────────────────────────────────────────────

SQL_SCHEMA = """
CREATE TABLE IF NOT EXISTS ТипыПартнёров (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    Тип  TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Партнёры (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    Тип          TEXT NOT NULL,
    Наименование TEXT NOT NULL,
    Директор     TEXT,
    Телефон      TEXT,
    Email        TEXT,
    Адрес        TEXT,
    Рейтинг      INTEGER DEFAULT 0,
    FOREIGN KEY (Тип) REFERENCES ТипыПартнёров(Тип)
);

CREATE TABLE IF NOT EXISTS Продукты (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    Наименование TEXT NOT NULL,
    Цена         REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ИсторияПродаж (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ПартнёрId   INTEGER NOT NULL,
    ПродуктId   INTEGER NOT NULL,
    Дата        TEXT DEFAULT (date('now')),
    Количество  INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (ПартнёрId) REFERENCES Партнёры(id),
    FOREIGN KEY (ПродуктId) REFERENCES Продукты(id)
);
"""

SQL_DATA = """
INSERT OR IGNORE INTO ТипыПартнёров (Тип) VALUES
    ('ЗАО'), ('ООО'), ('ПАО'), ('ОАО'), ('ИП');

INSERT OR IGNORE INTO Партнёры (Тип, Наименование, Директор, Телефон, Email, Адрес, Рейтинг) VALUES
    ('ООО', 'Альфа Трейд',  'Иванов И.И.',  '+7(900)111-22-33', 'alpha@mail.ru',  'г. Москва, ул. Ленина 1',    5),
    ('ИП',  'Бета Сервис',  'Петров П.П.',  '+7(900)444-55-66', 'beta@mail.ru',   'г. СПб, Невский пр. 10',     4),
    ('ПАО', 'Гамма Групп',  'Сидоров С.С.', '+7(900)777-88-99', 'gamma@mail.ru',  'г. Екб, ул. Мира 5',         3),
    ('ЗАО', 'Дельта ЛТД',   'Козлов К.К.',  '+7(900)000-11-22', 'delta@mail.ru',  'г. НСК, пр. Победы 20',      5),
    ('ОАО', 'Эпсилон Ко',   'Морозов М.М.', '+7(900)333-44-55', 'epsilon@mail.ru','г. Казань, ул. Баумана 15',   2);

INSERT OR IGNORE INTO Продукты (Наименование, Цена) VALUES
    ('Товар А', 1000.00),
    ('Товар Б', 2500.50),
    ('Товар В',  750.25),
    ('Товар Г', 3200.00),
    ('Товар Д', 1850.75);

INSERT OR IGNORE INTO ИсторияПродаж (ПартнёрId, ПродуктId, Дата, Количество) VALUES
    (1, 1, '2024-01-15', 10),
    (1, 2, '2024-02-20',  5),
    (2, 3, '2024-03-01',  8),
    (3, 4, '2024-03-10',  2),
    (4, 1, '2024-04-05', 15),
    (5, 5, '2024-04-20',  3);
"""

# ──────────────────────────────────────────────

def main():
    if os.path.exists(DB_FILE):
        ans = input(f"База '{os.path.basename(DB_FILE)}' уже существует. Пересоздать? (y/N): ")
        if ans.strip().lower() != "y":
            print("Отмена.")
            return
        os.remove(DB_FILE)

    conn = sqlite3.connect(DB_FILE)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SQL_SCHEMA)
    conn.executescript(SQL_DATA)
    conn.commit()
    conn.close()
    print(f"✓ БД создана: {DB_FILE}")

if __name__ == "__main__":
    main()
