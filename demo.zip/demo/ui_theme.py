# -*- coding: utf-8 -*-
"""Единая тёмная тема: шрифты, цвета, фабрики виджетов CustomTkinter."""
import tkinter as tk
from tkinter import ttk
import customtkinter as ctk

from config import PALETTE, TYPEFACE, UI
from fonts import load_montserrat, FONT_FAMILY

P = PALETTE
U = UI

_WEIGHT = {
    "normal": "normal",
    "medium": "normal",
    "semibold": "bold",
    "bold": "bold",
}

_BTN = {
    "primary":  (P["primary"],       P["primary_hover"],  P["text_on_primary"]),
    "success":  (P["success"],       P["success_hover"],  P["text_on_primary"]),
    "danger":   (P["error"],         P["error_hover"],    P["text_on_primary"]),
    "accent":   (P["accent"],        P["accent_hover"],   P["text_on_primary"]),
    "ghost":    (P["ghost"],         P["ghost_hover"],    P["text"]),
    "muted":    (P["surface_hover"], P["border"],         P["text_muted"]),
}


_BOLD = frozenset({"display", "title", "btn"})


def F(style="label", size=None, weight=None):
    """CTkFont с локальным Montserrat."""
    spec = TYPEFACE.get(style, TYPEFACE["label"])
    if isinstance(spec, tuple):
        sz = spec[1]
        w = weight or (spec[2] if len(spec) > 2 else "normal")
    else:
        sz = spec
        w = weight or ("bold" if style in _BOLD else "normal")
    return ctk.CTkFont(
        family=FONT_FAMILY,
        size=size or sz,
        weight=_WEIGHT.get(w, w),
    )


def tk_face(style="label"):
    """Кортеж шрифта для tkinter / ttk."""
    spec = TYPEFACE.get(style, TYPEFACE["label"])
    if isinstance(spec, tuple):
        return spec
    if style in _BOLD:
        return (FONT_FAMILY, spec, "bold")
    return (FONT_FAMILY, spec)


def init_theme(root=None):
    """Вызывать один раз при старте приложения."""
    load_montserrat()
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    if root is not None:
        try:
            root.configure(fg_color=P["bg"])
        except Exception:
            pass
    init_ttk()


def init_ttk():
    s = ttk.Style()
    s.theme_use("clam")
    s.configure(
        "Treeview",
        font=tk_face("label"),
        rowheight=U["row_height"],
        fieldbackground=P["surface"],
        background=P["surface"],
        foreground=P["text"],
        bordercolor=P["border"],
        lightcolor=P["surface"],
        darkcolor=P["surface"],
    )
    s.configure(
        "Treeview.Heading",
        font=tk_face("btn"),
        background=P["primary"],
        foreground=P["header_text"],
        relief="flat",
        borderwidth=0,
    )
    s.map("Treeview.Heading", background=[("active", P["primary_hover"])])
    s.map(
        "Treeview",
        background=[("selected", P["row_selected"])],
        foreground=[("selected", P["text_on_primary"])],
    )
    s.configure(
        "Vertical.TScrollbar",
        background=P["scroll"],
        troughcolor=P["bg_elevated"],
        bordercolor=P["border"],
        arrowcolor=P["text_muted"],
        darkcolor=P["scroll"],
        lightcolor=P["scroll"],
    )
    s.map("Vertical.TScrollbar", background=[("active", P["scroll_hover"])])
    s.configure(
        "Horizontal.TScrollbar",
        background=P["scroll"],
        troughcolor=P["bg_elevated"],
        bordercolor=P["border"],
        arrowcolor=P["text_muted"],
        darkcolor=P["scroll"],
        lightcolor=P["scroll"],
    )
    s.map("Horizontal.TScrollbar", background=[("active", P["scroll_hover"])])


def lbl(parent, text, style="label", color=None, **kw):
    return ctk.CTkLabel(
        parent, text=text,
        font=F(style),
        text_color=color or P["text"],
        **kw,
    )


def btn(parent, text, command=None, variant="primary", **kw):
    fg, hover, tc = _BTN.get(variant, _BTN["primary"])
    defaults = dict(
        font=F("btn"),
        fg_color=fg,
        hover_color=hover,
        text_color=tc,
        corner_radius=U.get("corner_btn", 18),
        height=U["btn_height_sm"],
        border_width=0,
    )
    defaults.update(kw)
    return ctk.CTkButton(parent, text=text, command=command, **defaults)


def entry(parent, **kw):
    defaults = dict(
        font=F("caption"),
        height=U["entry_height"],
        corner_radius=U["corner_sm"],
        border_width=1,
        border_color=P["border"],
        fg_color=P["input_bg"],
        text_color=P["text"],
    )
    defaults.update(kw)
    return ctk.CTkEntry(parent, **defaults)


def combo(parent, **kw):
    defaults = dict(
        font=F("caption"),
        height=U["btn_height_sm"],
        corner_radius=U["corner_sm"],
        border_width=1,
        border_color=P["border"],
        fg_color=P["input_bg"],
        button_color=P["primary"],
        button_hover_color=P["primary_hover"],
        dropdown_fg_color=P["surface"],
        dropdown_hover_color=P["surface_hover"],
        dropdown_text_color=P["text"],
        text_color=P["text"],
    )
    defaults.update(kw)
    return ctk.CTkComboBox(parent, **defaults)


def card(parent, **kw):
    defaults = dict(
        fg_color=P["surface"],
        corner_radius=U["corner"],
        border_width=1,
        border_color=P["border"],
    )
    defaults.update(kw)
    return ctk.CTkFrame(parent, **defaults)


def header_bar(parent, **kw):
    defaults = dict(
        fg_color=P["primary"],
        corner_radius=0,
        height=U["header_height"],
    )
    defaults.update(kw)
    return ctk.CTkFrame(parent, **defaults)


def toolbar(parent, **kw):
    defaults = dict(
        fg_color=P["surface"],
        corner_radius=U["corner"],
        height=U["toolbar_height"],
        border_width=1,
        border_color=P["border"],
    )
    defaults.update(kw)
    return ctk.CTkFrame(parent, **defaults)


def scroll_frame(parent, **kw):
    defaults = dict(
        fg_color=P["bg"],
        corner_radius=U["corner"],
        scrollbar_button_color=P["scroll"],
        scrollbar_button_hover_color=P["scroll_hover"],
        scrollbar_fg_color=P["bg_elevated"],
    )
    defaults.update(kw)
    return ctk.CTkScrollableFrame(parent, **defaults)


def tabview(parent, **kw):
    defaults = dict(
        fg_color=P["bg"],
        segmented_button_fg_color=P["surface"],
        segmented_button_selected_color=P["primary"],
        segmented_button_selected_hover_color=P["primary_hover"],
        segmented_button_unselected_color=P["bg_elevated"],
        segmented_button_unselected_hover_color=P["surface_hover"],
        text_color=P["text"],
        text_color_disabled=P["text_muted"],
        corner_radius=U["corner"],
    )
    defaults.update(kw)
    return ctk.CTkTabview(parent, **defaults)
